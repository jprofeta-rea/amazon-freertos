var group__CMSIS__FPSCR =
[
    [ "FPSCR Bits", "group__CMSIS__FPSCR__BITS.html", null ],
    [ "FPSCR_Type", "structFPSCR__Type.html", null ],
    [ "__get_FPSCR", "group__CMSIS__FPSCR.html#ga6a275172e274ea7ce6c22030d07c6c64", null ],
    [ "__set_FPSCR", "group__CMSIS__FPSCR.html#ga17c6ff443c52c74125fefef7de5fee1d", null ]
];