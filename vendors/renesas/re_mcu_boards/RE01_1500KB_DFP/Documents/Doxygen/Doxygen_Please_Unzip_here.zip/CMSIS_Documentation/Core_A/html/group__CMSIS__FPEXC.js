var group__CMSIS__FPEXC =
[
    [ "__get_FPEXC", "group__CMSIS__FPEXC.html#gadde57667b9f81c468a49268513624b90", null ],
    [ "__set_FPEXC", "group__CMSIS__FPEXC.html#ga14ba90beb9b4712454f35ac453c45f5d", null ]
];