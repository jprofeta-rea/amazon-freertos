var searchData=
[
  ['nvic_20functions',['NVIC Functions',['../group__nvic__trustzone__functions.html',1,'']]]
];
