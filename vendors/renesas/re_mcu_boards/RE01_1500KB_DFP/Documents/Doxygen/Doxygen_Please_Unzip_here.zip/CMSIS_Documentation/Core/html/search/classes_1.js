var searchData=
[
  ['control_5ftype',['CONTROL_Type',['../unionCONTROL__Type.html',1,'']]],
  ['coredebug_5ftype',['CoreDebug_Type',['../structCoreDebug__Type.html',1,'']]]
];
