var group__CMSIS__CNTFRQ =
[
    [ "__get_CNTFRQ", "group__CMSIS__CNTFRQ.html#ga4b6c8f8689077d9b57f65dcff910dbf8", null ],
    [ "__set_CNTFRQ", "group__CMSIS__CNTFRQ.html#ga66d2d5070c8577f95e1d2e2bcb3ad143", null ]
];