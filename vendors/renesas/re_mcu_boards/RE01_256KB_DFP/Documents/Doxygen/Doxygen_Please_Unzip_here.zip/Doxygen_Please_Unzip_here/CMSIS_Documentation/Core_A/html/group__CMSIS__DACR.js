var group__CMSIS__DACR =
[
    [ "DACR Bits", "group__CMSIS__DACR__BITS.html", "group__CMSIS__DACR__BITS" ],
    [ "DACR Dn field values", "group__CMSIS__DACR__Dn.html", "group__CMSIS__DACR__Dn" ],
    [ "__get_DACR", "group__CMSIS__DACR.html#ga10278deb975c653555ee70178546aaa6", null ],
    [ "__set_DACR", "group__CMSIS__DACR.html#ga72e050de5b19cd6b683f6c234968b78b", null ]
];